package com.example.minerd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
