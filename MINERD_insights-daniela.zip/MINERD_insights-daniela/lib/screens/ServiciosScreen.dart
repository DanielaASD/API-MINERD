
import 'package:flutter/material.dart';
class ServiciosScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('services'), // Título de la pantalla
      ),
      body: Center(
        child:Text("Servicio") , // Mostramos el componente de presentación
      ),
    );
  }
}
