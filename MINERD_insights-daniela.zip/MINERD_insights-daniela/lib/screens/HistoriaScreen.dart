
import 'package:flutter/material.dart';
class HistoriaScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Presentación'),
      ),
      body: Center(
        child:Text("") , 
      ),
    );
  }
}
