
import 'package:flutter/material.dart';
class MapaScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('mapa'), // Título de la pantalla
      ),
      body: Center(
        child:Text("mapa 25 ") , 
      ),
    );
  }
}
