
import 'package:flutter/material.dart';
class VideoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('video'), // Título de la pantalla
      ),
      body: Center(
        child:Text("video"), // Mostramos el componente de presentación
      ),
    );
  }
}
